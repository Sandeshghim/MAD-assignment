package com.example.mad_i;

public class mode_l_for_u_m {

    String frm_id, frm_desc, dPosted, fir_st_nam_e, surn_am_e;

    public String getFirstname() {
        return fir_st_nam_e;
    }

    public void setFirstname(String fir_st_nam_e) {
        this.fir_st_nam_e = fir_st_nam_e;
    }

    public String getSurname() {
        return surn_am_e;
    }

    public void setSurname(String surn_am_e) {
        this.surn_am_e = surn_am_e;
    }

    public String getFrm_desc() {
        return frm_desc;
    }

    public void setFrm_desc(String frm_desc) {
        this.frm_desc = frm_desc;
    }

    public String getdPosted() {
        return dPosted;
    }

    public void setdPosted(String dPosted) {
        this.dPosted = dPosted;
    }

    public String getFrm_id() {
        return frm_id;
    }

    public void setFrm_id(String frm_id) {
        this.frm_id = frm_id;
    }

    public mode_l_for_u_m(String frm_id, String frm_desc, String dPosted, String fir_st_nam_e, String surn_am_e) {
        this.frm_id = frm_id;
        this.frm_desc = frm_desc;
        this.dPosted = dPosted;
        this.fir_st_nam_e = fir_st_nam_e;
        this.surn_am_e = surn_am_e;
    }
}
