package com.example.mad_i;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class dBase extends SQLiteOpenHelper {
    public dBase(@Nullable Context context) {
        super(context, "as2.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLITE_data_base) {

        sqLITE_data_base.execSQL("create table  users(username TEXT primary key, pass_wo_rd TEXT, fir_st_nam_e TEXT, surn_am_e TEXT, mo_bil_e TEXT, cou_ntr_y TEXT, dateRegistered TEXT, dateUpdated TEXT)");
        sqLITE_data_base.execSQL("create table forums(forum_id INTEGER primary key AUTOINCREMENT, user_email TEXT, fname TEXT, sname TEXT, forum_description TEXT, datePosted TEXT)");
        sqLITE_data_base.execSQL("create table comments(comment_id INTEGER primary key AUTOINCREMENT, forum_id INTEGER, user_email TEXT, fir_st_nam_e TEXT, surn_am_e TEXT, cm_t_t TEXT, datePosted TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLITE_data_base, int oldVersion, int newVersion) {

        sqLITE_data_base.execSQL("drop table if exists users");
        sqLITE_data_base.execSQL("drop table if exists forums");
        sqLITE_data_base.execSQL("drop table if exists comments");

        onCreate(sqLITE_data_base);

    }

    public boolean addingUser(String ma_i_l, String pass, String firstn, String surn, String mob, String cou_ntr_y, String dReg){

        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contVals = new ContentValues();
        contVals.put("username", ma_i_l);
        contVals.put("pass_wo_rd", pass);
        contVals.put("fir_st_nam_e", firstn);
        contVals.put("surn_am_e", surn);
        contVals.put("mo_bil_e", mob);
        contVals.put("cou_ntr_y", cou_ntr_y);
        contVals.put("dateRegistered", dReg);
        long outcome = database.insert("users", null, contVals);

        if(outcome== -1){
            return false;
        }
        else{
            return true;
        }

    }

    public boolean ifuserexists(String ma_i_l, String pass){

        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cur_so_r = database.rawQuery("SELECT * FROM users WHERE username = ? and pass_wo_rd = ?",new String[] {ma_i_l, pass});
        if(cur_so_r.getCount() > 0){
            return true;
        }
        else{
            return false;
        }

    }

    public Cursor alltheusers(){
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cur_so_r = database.rawQuery("SELECT * FROM users", null);
        return cur_so_r;
    }

    public boolean userIdentity(String username){

        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cur_so_r = database.rawQuery("SELECT * FROM users WHERE username = ?",new String[] {username});
        if(cur_so_r.getCount() > 0){
            return true;
        }
        else{
            return false;
        }

    }

    public boolean insertingFrms(String ma_i_l, String fname, String sname, String fdescription, String dPosted){

        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contVals = new ContentValues();
        contVals.put("user_email", ma_i_l);
        contVals.put("fname", fname);
        contVals.put("sname", sname);
        contVals.put("forum_description", fdescription);
        contVals.put("datePosted", dPosted);

        long ress = database.insert("forums", null, contVals);
        database.close();
        if(ress == -1){
            return false;
        }
        else{
            return true;
        }

    }

    public boolean insertingCmts(String ma_i_l, String fname, String sname, String fid, String comm, String dPosted){

        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contVals = new ContentValues();
        contVals.put("user_email", ma_i_l);
        contVals.put("fir_st_nam_e", fname);
        contVals.put("surn_am_e", sname);
        contVals.put("forum_id", fid);
        contVals.put("cm_t_t", comm);
        contVals.put("datePosted", dPosted);
        long ress = database.insert("comments", null, contVals);
        database.close();
        if(ress == -1){
            return false;
        }
        else{
            return true;
        }


    }

    public boolean proupdt(String ma_i_l, String pass, String fname, String sname, String mob, String cou_ntr_y, String dUpdated){


        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contVals = new ContentValues();
        contVals.put("pass_wo_rd", pass);
        contVals.put("fir_st_nam_e", fname);
        contVals.put("surn_am_e", sname);
        contVals.put("mo_bil_e", mob);
        contVals.put("cou_ntr_y", cou_ntr_y);
        contVals.put("dateUpdated", dUpdated);
        long ress = database.update("users", contVals, "username = ?", new String[] {ma_i_l});

        if(ress > 0){
            return true;
        }
        else{
            return false;
        }

    }

    public ArrayList<mode_l_pr_o> myprofile(String ema_il){

        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cur_so_r = database.rawQuery("SELECT * FROM users WHERE username = ?", new String[] {ema_il});

        ArrayList<mode_l_pr_o> profilearr = new ArrayList<>();


        while(cur_so_r.moveToNext()){
            mode_l_pr_o mode_l_pr_o = new mode_l_pr_o();


            mode_l_pr_o.ma_i_l = cur_so_r.getString(0);
            mode_l_pr_o.fir_st_nam_e = cur_so_r.getString(2);
            mode_l_pr_o.surn_am_e = cur_so_r.getString(3);
            mode_l_pr_o.pass = cur_so_r.getString(1);
            mode_l_pr_o.num_be_r = cur_so_r.getString(4);
            mode_l_pr_o.cou_ntr_y = cur_so_r.getString(5);
            profilearr.add(mode_l_pr_o);

        }

        return profilearr;

    }

    public Cursor commentsofFrms(String fid){
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor curc = database.rawQuery("SELECT * FROM comments WHERE forum_id = ?", new String[] {fid});
        return curc;
    }

    public Cursor frmsall(){

        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cur_so_r = database.rawQuery("SELECT * FROM forums", null);
        return cur_so_r;
    }

    public boolean deletefrm(String forum_id){

        SQLiteDatabase database = this.getWritableDatabase();
        long ress = database.delete("forums", "forum_id = ?", new String[] {forum_id});
        database.close();

        if(ress > 0){
            return true;
        }
        else{
            return false;
        }
    }

    public boolean deletecmts(String comment_id){

        SQLiteDatabase database = this.getWritableDatabase();
        long ress = database.delete("comments", "comment_id = ?", new String[] {comment_id});
        database.close();

        if(ress > 0){
            return true;
        }
        else{
            return false;
        }
    }

}
