package com.example.mad_i;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;



public class adap_ter_com_m extends RecyclerView.Adapter<adap_ter_com_m.myViewHolder> {

    private Context con_tex_t;
    ArrayList<mode_l_comm_ent> holderData;
    dBase dBase;

    public adap_ter_com_m(Context con_tex_t, ArrayList<mode_l_comm_ent> holderData) {
        this.holderData = holderData;
        this.con_tex_t = con_tex_t;
    }



    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {


        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.comment, parent, false);
        return new myViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder h, int pos_itio_n) {

        dBase = new dBase(con_tex_t);



        ViewGroup parent = (ViewGroup) h.commentDel_ete.getParent();

        if (parent != null) {
            parent.removeView(h.commentDel_ete);
        }

        h.comm_ent_i_d.setText(holderData.get(pos_itio_n).getCmt_id());
        h.naa_me.setText((holderData.get(pos_itio_n).getFirstname()) + " " + holderData.get(pos_itio_n).getSurname());
        h.cm_t_t.setText(holderData.get(pos_itio_n).getComm());
        h.now_date.setText(holderData.get(pos_itio_n).getdPosted());

    }

    @Override
    public int getItemCount() {
        return holderData.size();
    }

    class myViewHolder extends RecyclerView.ViewHolder {


        TextView naa_me, cm_t_t, now_date, comm_ent_i_d;
        Button commentDel_ete;

        public myViewHolder(@NonNull View itemView) {
            super(itemView);
            comm_ent_i_d = itemView.findViewById(R.id.comm_ent_i_d);
            naa_me = itemView.findViewById(R.id.naa_me);
            cm_t_t = itemView.findViewById(R.id.cm_t_t);
            now_date = itemView.findViewById(R.id.now_date);
            commentDel_ete = itemView.findViewById(R.id.commentDel_ete);
        }
    }
}
