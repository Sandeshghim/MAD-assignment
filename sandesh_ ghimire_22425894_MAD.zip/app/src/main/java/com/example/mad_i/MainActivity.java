package com.example.mad_i;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    EditText ma_i_l, pass_wo_rd;
    dBase dBase;
    Button lo_in_btn, regi_ste_r_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        ma_i_l = findViewById(R.id.ma_i_l);
        pass_wo_rd = findViewById(R.id.pass_wo_rd);
        lo_in_btn = findViewById(R.id.lo_in_btn);
        regi_ste_r_btn = findViewById(R.id.regi_ste_r_btn);
        dBase dBase = new dBase(this);

        lo_in_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mailI = ma_i_l.getText().toString().trim();
                String passwordW = pass_wo_rd.getText().toString().trim();

                if(mailI.equals("")||passwordW.equals("")){
                    Toast.makeText(MainActivity.this, "Enter all fields", Toast.LENGTH_SHORT).show();
                }

                else if(mailI.equals("admin") && passwordW.equals("admin")){

                    SharedPreferences spL = getSharedPreferences("logg_ed_us_er", Context.MODE_PRIVATE);
                    SharedPreferences.Editor editSpl = spL.edit();
                    editSpl.putString("ema_il_add_re_ss", "admin");
                    editSpl.putString("fir_st_na_me", "Admin");
                    editSpl.putString("sur_nam_e", "");
                    editSpl.apply();
                    Toast.makeText(MainActivity.this, "login successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, GeneralTimelineActivity.class);
                    startActivity(intent);
                    finish();

            }
                else{
                boolean ress = dBase.ifuserexists(mailI, passwordW);
                if(ress == true){


                    ArrayList<mode_l_pr_o> arrayProfile = dBase.myprofile(mailI);

                    for(int i=0; i<arrayProfile.size(); i++) {

                        String first = arrayProfile.get(i).fir_st_nam_e;
                        String sur = arrayProfile.get(i).surn_am_e;


                        SharedPreferences spL = getSharedPreferences("logg_ed_us_er", Context.MODE_PRIVATE);
                        SharedPreferences.Editor editSpl = spL.edit();
                        editSpl.putString("ema_il_add_re_ss", mailI);
                        editSpl.putString("fir_st_na_me", first);
                        editSpl.putString("sur_nam_e", sur);
                        editSpl.apply();
                    }
                    Toast.makeText(MainActivity.this, "successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, GeneralTimelineActivity.class);
                    startActivity(intent);
                    finish();
                }
                else{
                    Toast.makeText(MainActivity.this, "Incorrect", Toast.LENGTH_SHORT).show();

                }
            }}
        });
        regi_ste_r_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Registration.class);
                startActivity(intent);
            }
        });
    }
}