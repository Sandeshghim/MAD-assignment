package com.example.mad_i;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Registration extends AppCompatActivity {

    EditText fir_st_nam_e, surn_am_e, num_be_r,ema_il, pass_wo_rd, con_fir_m_pass_wor_d, cou_ntr_y;
    Button reg_b_tn;
    Calendar cal_en_da_r = Calendar.getInstance();
    dBase dBase;
    SimpleDateFormat simp_le_dat_e = new SimpleDateFormat("yyyy-MM-dd");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        dBase = new dBase(this);
        fir_st_nam_e = findViewById(R.id.fir_st_nam_e);
        surn_am_e = findViewById(R.id.surn_am_e);
        num_be_r = findViewById(R.id.num_be_r);
        ema_il = findViewById(R.id.ema_il);
        pass_wo_rd = findViewById(R.id.pass_wo_rd);
        con_fir_m_pass_wor_d = findViewById(R.id.con_fir_m_pass_wor_d);
        cou_ntr_y = findViewById(R.id.cou_ntr_y);
        reg_b_tn = findViewById(R.id.reg_b_tn);

        reg_b_tn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String fnValue = fir_st_nam_e.getText().toString().trim();
                String snValue = surn_am_e.getText().toString().trim();
                String mValue = num_be_r.getText().toString().trim();
                String cValue = cou_ntr_y.getText().toString().trim();
                String eValue = ema_il.getText().toString().trim();
                String pValue = pass_wo_rd.getText().toString().trim();
                String cpValue = con_fir_m_pass_wor_d.getText().toString().trim();
                String drValue = simp_le_dat_e.format(cal_en_da_r.getTime());

                if(fnValue.equals("")||snValue.equals("")||mValue.equals("")||cValue.equals("")||pValue.equals("")||eValue.equals("")||cpValue.equals("")){
                    Toast.makeText(Registration.this, "Please enter all the fields provided", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (pValue.length() >= 8) {
                        if (cpValue.equals(pValue)) {
                            boolean check = dBase.userIdentity(eValue);
                            if (check == false) {
                                boolean insertTest = dBase.addingUser(eValue, pValue, fnValue, snValue, mValue, cValue, drValue);
                                if (insertTest == true) {
                                    Toast.makeText(Registration.this, "successfull", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(Registration.this, MainActivity.class);
                                    startActivity(intent);
                                    finish();
                                } else {
                                    Toast.makeText(Registration.this, "failed", Toast.LENGTH_SHORT).show();
                                }

                            } else {
                                Toast.makeText(Registration.this, "Email exists", Toast.LENGTH_SHORT).show();
                            }
                        } else {
                            Toast.makeText(Registration.this, "Password failed to match", Toast.LENGTH_SHORT).show();
                        }

                    }
                    else{
                        Toast.makeText(Registration.this, "Password must be greater than 8 chars", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });

    }
}