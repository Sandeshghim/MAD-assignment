package com.example.mad_i;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class ProfileActivity extends AppCompatActivity {

    EditText fir_st_nam_e, surn_am_e, mo_bil_e, pass_wo_rd, cou_ntr_y;
    Button upd_ate_btn;
    Calendar cale_n_dar =Calendar.getInstance();
    SimpleDateFormat simp_le_dat_e = new SimpleDateFormat();
    dBase dBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        fir_st_nam_e = findViewById(R.id.fir_st_nam_e);
        surn_am_e = findViewById(R.id.surn_am_e);
        mo_bil_e = findViewById(R.id.mo_bil_e);
        pass_wo_rd = findViewById(R.id.pass_wo_rd);
        cou_ntr_y = findViewById(R.id.cou_ntr_y);
        upd_ate_btn = findViewById(R.id.upd_ate_btn);

        dBase = new dBase(this);

        SharedPreferences spL = getSharedPreferences("Id", Context.MODE_PRIVATE);
        String ema_il_add_re_ss = spL.getString("ema_il_add_re_ss", "");


        ArrayList<mode_l_pr_o> arrPro =dBase.myprofile(ema_il_add_re_ss);

        for(int i=0; i<arrPro.size(); i++) {

            fir_st_nam_e.setText(arrPro.get(i).fir_st_nam_e);
            surn_am_e.setText(arrPro.get(i).surn_am_e);
            pass_wo_rd.setText(arrPro.get(i).pass);
            mo_bil_e.setText(arrPro.get(i).num_be_r);
            cou_ntr_y.setText(arrPro.get(i).cou_ntr_y);
        }

        upd_ate_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String fir_st_na_me = fir_st_nam_e.getText().toString().trim();
                String sur_nam_e = surn_am_e.getText().toString().trim();
                String mobI = mo_bil_e.getText().toString().trim();
                String resI = cou_ntr_y.getText().toString().trim();
                String passW = pass_wo_rd.getText().toString().trim();
                String datE = simp_le_dat_e.format(cale_n_dar.getTime());

                if(passW.length() >= 8){
                    if(fir_st_na_me.equals("")||sur_nam_e.equals("")||mobI.equals("")||resI.equals("")||passW.equals("")){
                        Toast.makeText(ProfileActivity.this, "All fields required", Toast.LENGTH_SHORT).show();
                    }

                    else{
                        boolean updatePro = dBase.proupdt(ema_il_add_re_ss, passW, fir_st_na_me, sur_nam_e, mobI, resI, datE);
                        if(updatePro == true) {
                            Toast.makeText(ProfileActivity.this, "Updated : " + datE, Toast.LENGTH_SHORT).show();
                        }
                        else{
                            Toast.makeText(ProfileActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                        }

                    }
                }
                else{
                    Toast.makeText(ProfileActivity.this, "Enter valid pass_wo_rd", Toast.LENGTH_SHORT).show();
                }


            }
        });

    }
}