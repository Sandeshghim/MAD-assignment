package com.example.mad_i;

import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class UsersActivity extends AppCompatActivity {


    mode_l_use_r mode_l_use_r;
    adap_te_r_us_er adap_te_r_us_er;
    RecyclerView recy_cler_view_us_er_s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users);

        recy_cler_view_us_er_s = findViewById(R.id.recy_cler_view_us_er_s);

        dBase dBase = new dBase(this);
        ArrayList<mode_l_use_r> userdata = new ArrayList<mode_l_use_r>();
        recy_cler_view_us_er_s.setLayoutManager(new LinearLayoutManager(this));

        Cursor out = new dBase(this).alltheusers();
        while(out.moveToNext()) {

            mode_l_use_r obj = new mode_l_use_r(out.getString(0), out.getString(2), out.getString(3));
            userdata.add(obj);
        }

        adap_te_r_us_er = new adap_te_r_us_er(this, userdata);
        recy_cler_view_us_er_s.setAdapter(adap_te_r_us_er);
        DividerItemDecoration decor = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        recy_cler_view_us_er_s.addItemDecoration(decor);
    }
}