package com.example.mad_i;

public class mode_l_pr_o {

    String ma_i_l, num_be_r, pass, fir_st_nam_e, surn_am_e, cou_ntr_y;

}
