package com.example.mad_i;

public class mode_l_use_r {

    String ma_i_l, fir_st_nam_e, surn_am_e;

    public String getMail() {
        return ma_i_l;
    }

    public void setMail(String ma_i_l) {
        this.ma_i_l = ma_i_l;
    }

    public String getFirstname() {
        return fir_st_nam_e;
    }

    public void setFirstname(String fir_st_nam_e) {
        this.fir_st_nam_e = fir_st_nam_e;
    }

    public String getSurname() {
        return surn_am_e;
    }

    public void setSurname(String surn_am_e) {
        this.surn_am_e = surn_am_e;
    }

    public mode_l_use_r(String ma_i_l, String fir_st_nam_e, String surn_am_e) {
        this.ma_i_l = ma_i_l;
        this.fir_st_nam_e = fir_st_nam_e;
        this.surn_am_e = surn_am_e;
    }
}
