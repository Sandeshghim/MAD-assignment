package com.example.mad_i;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;

public class ForumInsert extends AppCompatActivity {

    EditText ne_w_foru_m;
    Button po_st_btn;
    dBase dBase;

    Calendar cale_n_dar = Calendar.getInstance();
    SimpleDateFormat simp_le_dat_e = new SimpleDateFormat();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forum_insert);


        ne_w_foru_m = findViewById(R.id.ne_w_foru_m);
        po_st_btn = findViewById(R.id.po_st_btn);

        dBase = new dBase(this);


        po_st_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String now = simp_le_dat_e.format(cale_n_dar.getTime());
                String cm_t_t = ne_w_foru_m.getText().toString();
                boolean ress = dBase.insertingFrms("admin", "Admin", "", cm_t_t, now);
                if(ress == true){

                    Toast.makeText(ForumInsert.this, "Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(ForumInsert.this, GeneralTimelineActivity.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(ForumInsert.this, "Try again, failed", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
}