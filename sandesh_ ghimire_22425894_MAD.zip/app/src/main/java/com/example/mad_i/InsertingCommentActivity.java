package com.example.mad_i;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

public class InsertingCommentActivity extends AppCompatActivity {


    RecyclerView comm_ent_rec_view;
    EditText new_comm_ent;
    Button po_st_btn;
    adap_ter_com_m adap_ter_com_m;
    adap_ter_com_edt_del adap_ter_com_edt_del;
    dBase dBase;
    Calendar cale_n_dar = Calendar.getInstance();
    SimpleDateFormat simp_le_dat_e = new SimpleDateFormat();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inserting_comment);

        SharedPreferences spl = getSharedPreferences("logg_ed_us_er", Context.MODE_PRIVATE);
        String ema_il_add_re_ss = spl.getString("ema_il_add_re_ss", "");
        String fir_st_nam_e = spl.getString("fir_st_na_me", "");
        String surn_am_e = spl.getString("sur_nam_e", "");

        Bundle ext_raas = getIntent().getExtras();
        String for_id = ext_raas.getString("frm_id");

        //for recycyler view

        ArrayList<mode_l_comm_ent> dat_a_hold_s = new ArrayList<mode_l_comm_ent>();

        comm_ent_rec_view = (RecyclerView)findViewById(R.id.comm_ent_rec_view);
        comm_ent_rec_view.setLayoutManager(new LinearLayoutManager(this));

        Cursor cur_so_r = new dBase(this).commentsofFrms(for_id);
        while(cur_so_r.moveToNext()) {

            mode_l_comm_ent obj = new mode_l_comm_ent(cur_so_r.getString(0),cur_so_r.getString(5), cur_so_r.getString(6), cur_so_r.getString(4), cur_so_r.getString(4));

            dat_a_hold_s.add(obj);
        }

        adap_ter_com_m = new adap_ter_com_m(this, dat_a_hold_s);
        adap_ter_com_edt_del = new adap_ter_com_edt_del(this, dat_a_hold_s);
        if(ema_il_add_re_ss.equals("admin")){
            comm_ent_rec_view.setAdapter(adap_ter_com_edt_del);
        }
        else if(!ema_il_add_re_ss.equals("admin")) {
            comm_ent_rec_view.setAdapter(adap_ter_com_m);
        }
        DividerItemDecoration itmdecor = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        comm_ent_rec_view.addItemDecoration(itmdecor);




        //for other function
        comm_ent_rec_view = findViewById(R.id.comm_ent_rec_view);
        new_comm_ent = findViewById(R.id.new_comm_ent);
        po_st_btn = findViewById(R.id.po_st_btn);


        dBase = new dBase(this);
        po_st_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String now = simp_le_dat_e.format(cale_n_dar.getTime());

                String comm = new_comm_ent.getText().toString();


                boolean ress = dBase.insertingCmts(ema_il_add_re_ss, fir_st_nam_e, surn_am_e, for_id, comm, now);
                if(ress==true){
                    Toast.makeText(InsertingCommentActivity.this, "Successful", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(InsertingCommentActivity.this, GeneralTimelineActivity.class);
                    startActivity(intent);
                }
                else{
                    Toast.makeText(InsertingCommentActivity.this, "Faied to post", Toast.LENGTH_SHORT).show();
                }

            }
        });



    }
}