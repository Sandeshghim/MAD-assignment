package com.example.mad_i;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class GeneralTimelineActivity extends AppCompatActivity {

    Button us_er_btn, pro_fil_e_btn, for_um_btn;
    RecyclerView generaltimelinerecview;
    dBase dBase;
    adap_ter_fr_m adap_ter_fr_m;
    adap_ter_r_del_frm adap_ter_r_del_frm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_general_timeline);

        us_er_btn = findViewById(R.id.us_er_btn);
        pro_fil_e_btn = findViewById(R.id.pro_fil_e_btn);
        for_um_btn = findViewById(R.id.for_um_btn);
        generaltimelinerecview = findViewById(R.id.generaltimelinerecview);

        SharedPreferences spL = getSharedPreferences("logg_ed_us_er", Context.MODE_PRIVATE);
        String ema_il_add_re_ss = spL.getString("ema_il_add_re_ss", "");



        if(!ema_il_add_re_ss.equals("admin")){

            ViewGroup parent = (ViewGroup) for_um_btn.getParent();
            ViewGroup parent2 = (ViewGroup) us_er_btn.getParent();
            if (parent != null) {
                parent2.removeView(us_er_btn);
                parent.removeView(for_um_btn);
            }
        }



        dBase = new dBase(this);
        ArrayList<mode_l_for_u_m> forumdata = new ArrayList<mode_l_for_u_m>();

        generaltimelinerecview = (RecyclerView)findViewById(R.id.generaltimelinerecview);
        generaltimelinerecview.setLayoutManager(new LinearLayoutManager(this));


        Cursor cur_so_r = new dBase(this).frmsall();
        while(cur_so_r.moveToNext()) {

            mode_l_for_u_m obj = new mode_l_for_u_m(cur_so_r.getString(0),cur_so_r.getString(4), cur_so_r.getString(5), cur_so_r.getString(2), cur_so_r.getString(3));

            forumdata.add(obj);
        }
        adap_ter_fr_m = new adap_ter_fr_m(this, forumdata);
        adap_ter_r_del_frm = new adap_ter_r_del_frm(this, forumdata);
        if(!ema_il_add_re_ss.equals("admin")) {
            generaltimelinerecview.setAdapter(adap_ter_fr_m);
        }else if(ema_il_add_re_ss.equals("admin")){
            ViewGroup parent = (ViewGroup) pro_fil_e_btn.getParent();

            if (parent != null) {
                parent.removeView(pro_fil_e_btn);
            }
            generaltimelinerecview.setAdapter(adap_ter_r_del_frm);
        }


        DividerItemDecoration decor = new DividerItemDecoration(this, DividerItemDecoration.VERTICAL);
        generaltimelinerecview.addItemDecoration(decor);


        us_er_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GeneralTimelineActivity.this, UsersActivity.class);
                startActivity(intent);
            }
        });

        pro_fil_e_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GeneralTimelineActivity.this, ProfileActivity.class);
                startActivity(intent);
            }
        });
        for_um_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(GeneralTimelineActivity.this, ForumInsert.class);
                startActivity(intent);
            }
        });
    }
}