package com.example.mad_i;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class adap_ter_fr_m extends RecyclerView.Adapter<adap_ter_fr_m.myViewHolder>{

    private Context context;
    ArrayList<mode_l_for_u_m> holderData;
    dBase dBase;

    public adap_ter_fr_m(Context context, ArrayList<mode_l_for_u_m> holderData) {
        this.holderData = holderData;
        this.context = context;
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.forum, parent, false);
        return new myViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holderV, int pos_itio_n) {

        dBase =new dBase(context);

        ViewGroup parent = (ViewGroup) holderV.del_ete_frm.getParent();

        if (parent != null) {
            parent.removeView(holderV.del_ete_frm);
        }


        holderV.for_um_i_d.setText(holderData.get(pos_itio_n).getFrm_id());
        holderV.naa_me.setText(holderData.get(pos_itio_n).getFirstname()+ " " + holderData.get(pos_itio_n).getSurname());
        holderV.now_date.setText(holderData.get(pos_itio_n).getdPosted());
        holderV.forum.setText(holderData.get(pos_itio_n).getFrm_desc());

        holderV.forum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, InsertingCommentActivity.class);
                intent.putExtra("frm_id", holderV.for_um_i_d.getText());
                context.startActivity(intent);
            }
        });
    }



    @Override
    public int getItemCount() {
        return holderData.size();
    }

    class myViewHolder extends RecyclerView.ViewHolder{

        TextView for_um_i_d, naa_me, now_date, forum;
        Button del_ete_frm;

        public myViewHolder(@NonNull View itemView) {
            super(itemView);

            for_um_i_d = itemView.findViewById(R.id.for_um_i_d);
            naa_me = itemView.findViewById(R.id.naa_me);
            now_date = itemView.findViewById(R.id.now_date);
            forum = itemView.findViewById(R.id.forum);
            del_ete_frm = itemView.findViewById(R.id.del_ete_frm);

        }
    }
}
