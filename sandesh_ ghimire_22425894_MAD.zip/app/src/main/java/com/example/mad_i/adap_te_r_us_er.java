package com.example.mad_i;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class adap_te_r_us_er extends RecyclerView.Adapter<adap_te_r_us_er.myViewHolder>{

    private Context context;
    ArrayList<mode_l_use_r> holderData;
    dBase dBase;

    public adap_te_r_us_er(Context context, ArrayList<mode_l_use_r> holderData) {
        this.holderData = holderData;
        this.context = context;
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

    View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.user, parent, false);
    return new myViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holderV, int pos_itio_n) {

        dBase =new dBase(context);
        holderV.use_rI_d.setText(holderData.get(pos_itio_n).getMail());
        holderV.naa_me.setText(holderData.get(pos_itio_n).getFirstname()+ " " + holderData.get(pos_itio_n).getSurname());
    }


    @Override
    public int getItemCount() {
        return holderData.size();
    }

    class myViewHolder extends RecyclerView.ViewHolder{

        TextView use_rI_d, naa_me;

        public myViewHolder(@NonNull View itemView) {
            super(itemView);

            use_rI_d = itemView.findViewById(R.id.use_rI_d);
            naa_me = itemView.findViewById(R.id.naa_me);
        }
    }
}
