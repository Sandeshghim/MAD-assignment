package com.example.mad_i;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class adap_ter_r_del_frm extends RecyclerView.Adapter<adap_ter_r_del_frm.myViewHolder>{

    private Context context;
    ArrayList<mode_l_for_u_m> holderData;
    dBase dBase;

    public adap_ter_r_del_frm(Context context, ArrayList<mode_l_for_u_m> holderData) {
        this.holderData = holderData;
        this.context = context;
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.forum, parent, false);
        return new myViewHolder(v);

    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holderV, int pos_itio_n) {

        dBase =new dBase(context);


        holderV.for_um_i_d.setText(holderData.get(pos_itio_n).getFrm_id());
        holderV.forum.setText(holderData.get(pos_itio_n).getFrm_desc());
        holderV.now_date.setText(holderData.get(pos_itio_n).getdPosted());
        holderV.naa_me.setText(holderData.get(pos_itio_n).getFirstname()+ " " + holderData.get(pos_itio_n).getSurname());

        holderV.forum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, InsertingCommentActivity.class);
                intent.putExtra("frm_id", holderV.for_um_i_d.getText());
                context.startActivity(intent);
            }
        });

        holderV.del_ete_frm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("frm", holderV.for_um_i_d.getText().toString());

                boolean ress = dBase.deletefrm(holderV.for_um_i_d.getText().toString());
                if(ress == true){
                    Toast.makeText(context, "Forum deleted", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(context, GeneralTimelineActivity.class);
                    context.startActivity(intent);
                }
                else{
                    Toast.makeText(context, "Deleting failed", Toast.LENGTH_SHORT).show();
                }


            }
        });
    }



    @Override
    public int getItemCount() {
        return holderData.size();
    }

    class myViewHolder extends RecyclerView.ViewHolder{

        TextView for_um_i_d, naa_me, now_date, forum;
        Button del_ete_frm;

        public myViewHolder(@NonNull View itemView) {
            super(itemView);

            for_um_i_d = itemView.findViewById(R.id.for_um_i_d);
            forum = itemView.findViewById(R.id.forum);
            now_date = itemView.findViewById(R.id.now_date);
            naa_me = itemView.findViewById(R.id.naa_me);
            del_ete_frm = itemView.findViewById(R.id.del_ete_frm);

        }
    }
}
