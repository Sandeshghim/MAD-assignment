package com.example.mad_i;

public class mode_l_comm_ent {

    String fir_st_nam_e, surn_am_e, dPosted, cmt_id, comm;

    public String getFirstname() {
        return fir_st_nam_e;
    }

    public void setFirstname(String fir_st_nam_e) {
        this.fir_st_nam_e = fir_st_nam_e;
    }

    public String getSurname() {
        return surn_am_e;
    }

    public void setSurname(String surn_am_e) {
        this.surn_am_e = surn_am_e;
    }

    public String getdPosted() {
        return dPosted;
    }

    public void setdPosted(String dPosted) {
        this.dPosted = dPosted;
    }

    public String getCmt_id() {
        return cmt_id;
    }

    public void setCmt_id(String cmt_id) {
        this.cmt_id = cmt_id;
    }

    public String getComm() {
        return comm;
    }

    public void setComm(String comm) {
        this.comm = comm;
    }

    public mode_l_comm_ent(String cmt_id, String comm, String dPosted, String fir_st_nam_e, String surn_am_e) {
        this.cmt_id = cmt_id;
        this.comm = comm;
        this.dPosted = dPosted;
        this.fir_st_nam_e = fir_st_nam_e;
        this.surn_am_e = surn_am_e;
    }
}
